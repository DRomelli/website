# JCMS Analysis Script
# Authors: Federico Maria Ferrara, Davide Romelli, Donato Masciandaro, Manuela Moschella
# Paper What Do Politicians Think of Technocratic Institutions? European Parliament's Attitudes Towards the European Central Bank
# Date: 04.05.2024

# Clearing workspace for clean start
rm(list=ls(all=TRUE))

# Set working directory path
# setwd("C:/Users/your path to data")

# Load required libraries
packages <- c("dplyr", "tidyverse", "janitor", "glue", "rlang",
              "naniar", "RColorBrewer", "MASS", "ggthemes", "readr", "tidyr")
sapply(packages, function(p) if (!p %in% installed.packages()) install.packages(p))
sapply(packages, library, character.only = TRUE)


# Helper functions ---------------------------------------------------------

#function to import/clean datasets
import_qualtrics <- function(data){
  
  drop_vct <- c("ResponseId", 
                "DistributionChannel", "UserLanguage")
  
  df <- read_csv(data) %>% 
    slice(3:n()) %>% 
    clean_names() %>% 
    relocate(recorded_date, .after = end_date) %>% 
    ungroup()
}

#function to merge two variants of an experiment
vimerger_two <- function(df = data, e, q){
  n <- df %>% 
    unite(!!glue(sym(e),"_",q,sep = ""), c(!!glue(sym(e),"_1_",q, sep = ""), 
                                           !!glue(sym(e),"_2_",q, sep = "")), 
          na.rm = TRUE) %>% 
    dplyr::select("colname" = !!glue(sym(e),"_",q, sep = "")) %>% 
    mutate(colname = as.numeric(colname))
  
  colnames(n) <- c(as_string(glue(sym(e),"_",q, sep = "")))
  n
  
}


#function to merge three variants of an experiment
vimerger_three <- function(df = data, e, q){
  n <- df %>% 
    unite(!!glue(sym(e),"_",q,sep = ""), c(!!glue(sym(e),"_1_",q, sep = ""), 
                                           !!glue(sym(e),"_2_",q, sep = ""), 
                                           !!glue(sym(e),"_3_",q, sep = "")), 
          na.rm = TRUE) %>% 
    dplyr::select("colname" = !!glue(sym(e),"_",q, sep = "")) %>% 
    mutate(colname = as.numeric(colname))
  
  colnames(n) <- c(as_string(glue(sym(e),"_",q, sep = "")))
  n
  
}

# function to create an empty dataframe to loop into
df_creator <- function(df_rows = nrow(data), df_cols = i){
  df <- data.frame(matrix(nrow = df_rows, ncol = df_cols))
}

# preparing the data ------------------------------------------------------

elite_data <- import_qualtrics("JCMS data numeric.csv")
elite_data_text <- import_qualtrics("JCMS data text.csv")

# rename variables to make consistent

names(elite_data)[names(elite_data) == 'q4_1_1'] <- 'q4_1'
names(elite_data)[names(elite_data) == 'q4_2_1'] <- 'q4_2'
names(elite_data)[names(elite_data) == 'q5_1_1'] <- 'q5_1'

names(elite_data)[names(elite_data) == 'e1_1_2_1'] <- 'e1_1_2'
names(elite_data)[names(elite_data) == 'e1_2_2_1'] <- 'e1_2_2'

# include text variables
elite_data$country <- elite_data_text$q2_1
elite_data$age <- elite_data_text$q2_2
elite_data$ecb_news <- elite_data_text$q3_1
elite_data$ecb_discussion <- elite_data_text$q3_2
elite_data$econ_participation <- elite_data_text$q3_3
elite_data$transparency <- elite_data_text$q5_2
elite_data$politicization <- elite_data_text$q5_3

elite_data$n <- 1 # to create summary statistics based on counts

# recode variables 

elite_data <- elite_data %>%
  replace_with_na(replace = list(q5_2= 3,
                                 e1_1_3 = 12,
                                 e1_2_3 = 12,
                                 e2_1_4 = 3,
                                 e2_2_4 = 3,
                                 e2_3_4 = 3))

elite_data$q3_1[elite_data$q3_1 == 23] <- 1
elite_data$q3_1[elite_data$q3_1 == 24] <- 2
elite_data$q3_1[elite_data$q3_1 == 28] <- 3
elite_data$q3_1[elite_data$q3_1 == 29] <- 4

elite_data$q3_3[elite_data$q3_3 == 5] <- 4

elite_data$e1_1_3[elite_data$e1_1_3 == 7] <- 1
elite_data$e1_1_3[elite_data$e1_1_3 == 8] <- 2
elite_data$e1_1_3[elite_data$e1_1_3 == 9] <- 3
elite_data$e1_1_3[elite_data$e1_1_3 == 10] <- 4
elite_data$e1_1_3[elite_data$e1_1_3 == 11] <- 5

elite_data$e1_2_3[elite_data$e1_2_3 == 7] <- 1
elite_data$e1_2_3[elite_data$e1_2_3 == 8] <- 2
elite_data$e1_1_3[elite_data$e1_2_3 == 9] <- 3
elite_data$e1_2_3[elite_data$e1_2_3 == 10] <- 4
elite_data$e1_2_3[elite_data$e1_2_3 == 11] <- 5

elite_data$e2_1_2[elite_data$e2_1_2 == 18] <- 1
elite_data$e2_1_2[elite_data$e2_1_2 == 19] <- 2
elite_data$e2_1_2[elite_data$e2_1_2 == 20] <- 3
elite_data$e2_1_2[elite_data$e2_1_2 == 21] <- 4
elite_data$e2_1_2[elite_data$e2_1_2 == 22] <- 5

elite_data$e2_2_2[elite_data$e2_2_2 == 18] <- 1
elite_data$e2_2_2[elite_data$e2_2_2 == 19] <- 2
elite_data$e2_2_2[elite_data$e2_2_2 == 20] <- 3
elite_data$e2_2_2[elite_data$e2_2_2 == 21] <- 4
elite_data$e2_2_2[elite_data$e2_2_2 == 22] <- 5

elite_data$e2_3_2[elite_data$e2_3_2 == 18] <- 1
elite_data$e2_3_2[elite_data$e2_3_2 == 19] <- 2
elite_data$e2_3_2[elite_data$e2_3_2 == 20] <- 3
elite_data$e2_3_2[elite_data$e2_3_2 == 21] <- 4
elite_data$e2_3_2[elite_data$e2_3_2 == 22] <- 5

elite_data$e2_1_3[elite_data$e2_1_3 == 6] <- 1
elite_data$e2_1_3[elite_data$e2_1_3 == 7] <- 2
elite_data$e2_1_3[elite_data$e2_1_3 == 8] <- 3
elite_data$e2_1_3[elite_data$e2_1_3 == 9] <- 4
elite_data$e2_1_3[elite_data$e2_1_3 == 10] <- 5

elite_data$e2_2_3[elite_data$e2_2_3 == 6] <- 1
elite_data$e2_2_3[elite_data$e2_2_3 == 7] <- 2
elite_data$e2_2_3[elite_data$e2_2_3 == 8] <- 3
elite_data$e2_2_3[elite_data$e2_2_3 == 9] <- 4
elite_data$e2_2_3[elite_data$e2_2_3 == 10] <- 5

elite_data$e2_3_3[elite_data$e2_3_3 == 6] <- 1
elite_data$e2_3_3[elite_data$e2_3_3 == 7] <- 2
elite_data$e2_3_3[elite_data$e2_3_3 == 8] <- 3
elite_data$e2_3_3[elite_data$e2_3_3 == 9] <- 4
elite_data$e2_3_3[elite_data$e2_3_3 == 10] <- 5

elite_data$e2_1_4[elite_data$e2_1_4 == 1] <- 0
elite_data$e2_1_4[elite_data$e2_1_4 == 2] <- 1

elite_data$e2_2_4[elite_data$e2_2_4 == 1] <- 0
elite_data$e2_2_4[elite_data$e2_2_4 == 2] <- 1

elite_data$e2_3_4[elite_data$e2_3_4 == 1] <- 0
elite_data$e2_3_4[elite_data$e2_3_4 == 2] <- 1

# drop incomplete survey responses

data_more_than_2min <- elite_data[as.numeric(elite_data$duration_in_seconds)>120,]
data_analysis <- data_more_than_2min[as.numeric(data_more_than_2min$progress)>50,]

# merging columns ---------------------------------------------------------

# first experiment
e1_option <- data_analysis %>% 
  dplyr::select(contains("e1")) %>% 
  mutate(e1_option = case_when(!is.na(e1_1_3) ~ 1, # no treatment 
                               !is.na(e1_2_3) ~ 2)) %>% 
  dplyr::select(e1_option)

e1_2 <- vimerger_two(data_analysis, e = "e1", q = 2)
e1_3 <- vimerger_two(data_analysis, e = "e1", q = 3)


data_analysis$e1_option <- as.numeric(e1_option$e1_option)
data_analysis$treatment_1[data_analysis$e1_option==1] <- "control"
data_analysis$treatment_1[data_analysis$e1_option==2] <- "treatment"
data_analysis$treatment_1 <- relevel(as.factor(data_analysis$treatment_1), ref="control")

data_analysis$e1_2 <- as.numeric(e1_2$e1_2)
data_analysis$e1_3 <- as.numeric(e1_3$e1_3)

# second experiment
e2_option <- data_analysis %>% 
  dplyr::select(contains("e2")) %>% 
  mutate(e2_option = case_when(!is.na(e2_1_2) ~ 1, # baseline
                               !is.na(e2_2_2) ~ 2, # hawkish
                               !is.na(e2_3_2) ~ 3)) %>% 
  dplyr::select(e2_option)

e2_2 <- vimerger_three(data_analysis, e = "e2", q = 2)
e2_3 <- vimerger_three(data_analysis, e = "e2", q = 3)
e2_4 <- vimerger_three(data_analysis, e = "e2", q = 4)

data_analysis$e2_option <- as.numeric(e2_option$e2_option)
data_analysis$treatment_2[data_analysis$e2_option==1] <- "control"
data_analysis$treatment_2[data_analysis$e2_option==2] <- "hawkish"
data_analysis$treatment_2[data_analysis$e2_option==3] <- "dovish"
data_analysis$treatment_2 <- relevel(as.factor(data_analysis$treatment_2), ref="control")

data_analysis$e2_2 <- as.numeric(e2_2$e2_2)
data_analysis$e2_3 <- as.numeric(e2_3$e2_3)
data_analysis$e2_4 <- as.numeric(e2_4$e2_4)

# descriptive analysis ---------------------------------------------------------

# country distribution

country_count <- aggregate(data_analysis$n, by=list(data_analysis$country), FUN=sum)
colnames(country_count) <- c("Country", "Frequency")

country_count <- country_count[order(-country_count$Frequency),] # Sort by frequency
country_count$Country <- factor(country_count$Country, country_count$Country) # Fix the order of rows

country_distrib_plot <- ggplot(country_count, aes(x=Country, y=Frequency, fill=Frequency)) + geom_bar(stat = "identity",  color = "black",
                                                                                                      width = 0.8, position="dodge") + 
  scale_fill_gradient(low = "white", high = "dodgerblue4", name="") + theme_classic() + 
  ylab("N. of Survey Responses") + xlab("Country") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                           axis.title.x = element_text(margin=margin(0,0,0,0))) +
  scale_y_continuous(limits = c(0,12), expand=c(0,0)) + 
  theme(axis.text.x = element_text(angle = 90, size= 12, hjust = 1, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) 


country_distrib_plot
#dev.copy2pdf(file="summary statistics/country_distribution.pdf", width=10, height=6)

# age distribution

age_count <- aggregate(data_analysis$n, by=list(data_analysis$age), FUN=sum)
colnames(age_count) <- c("Age", "Frequency")

age_count$Age <- factor(age_count$Age, age_count$Age) # Fix the order of rows

age_distrib_plot <- ggplot(age_count, aes(x=Age, y=Frequency, fill=Frequency)) + geom_bar(stat = "identity",  color = "black", fill = "dodgerblue4",
                                                                                          width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab("Age") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                         axis.title.x = element_text(margin=margin(0,0,0,0))) +
  scale_y_continuous(limits = c(0,30), expand=c(0,0)) + 
  theme(axis.text.x = element_text(angle = 90, size= 12, hjust = 1, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) 


age_distrib_plot
#dev.copy2pdf(file="summary statistics/age_distribution.pdf", width=10, height=6)

# attention to ecb news

ecb_news_count <- aggregate(data_analysis$n, by=list(data_analysis$ecb_news), FUN=sum)
ecb_news_count[4,] <- c("No attention at all", 0)
colnames(ecb_news_count) <- c("News", "Frequency")

ecb_news_count$News <- factor(ecb_news_count$News, c("No attention at all",
                                                     "Little attention",
                                                     "Some attention",
                                                     "A lot of attention")) # Fix the order of rows
ecb_news_count$Frequency <- as.numeric(ecb_news_count$Frequency)

ecb_news_distrib_plot <- ggplot(ecb_news_count, aes(x=News, y=Frequency, fill=Frequency)) + geom_bar(stat = "identity",  color = "black", fill = "dodgerblue4",
                                                                                                     width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab("Attention to ECB News") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                           axis.title.x = element_text(margin=margin(0,0,0,0))) +
  scale_y_continuous(limits = c(0,30), expand=c(0,0)) + 
  theme(axis.text.x = element_text(angle = 90, size= 12, hjust = 1, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) 

ecb_news_distrib_plot
#dev.copy2pdf(file="summary statistics/attention_ecb_news_distribution.pdf", width=10, height=6)

# discussion of ecb matters in parliamentary activities

ecb_discussion_count <- aggregate(data_analysis$n, by=list(data_analysis$ecb_discussion), FUN=sum)
ecb_discussion_count[4,] <- c("On a daily basis", 0)
colnames(ecb_discussion_count) <- c("Discussion", "Frequency")

ecb_discussion_count$Discussion <- factor(ecb_discussion_count$Discussion, c("Never",
                                                                             "Occasionally",
                                                                             "Regularly",
                                                                             "On a daily basis")) # Fix the order of rows
ecb_discussion_count$Frequency <- as.numeric(ecb_discussion_count$Frequency)

ecb_discussion_distrib_plot <- ggplot(ecb_discussion_count, aes(x=Discussion, y=Frequency, fill=Frequency)) + geom_bar(stat = "identity",  color = "black", fill = "dodgerblue4",
                                                                                                                       width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab("Discussion of ECB Matters in Parliamentary Activities") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                                                           axis.title.x = element_text(margin=margin(10,0,0,0))) +
  scale_y_continuous(limits = c(0,30), expand=c(0,0)) + 
  theme(axis.text.x = element_text(angle = 90, size= 12, hjust = 1, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) 

ecb_discussion_distrib_plot
#dev.copy2pdf(file="summary statistics/discussing_ecb_matters_distribution.pdf", width=10, height=6)

# participation in ECON hearings

econ_participation_count <- aggregate(data_analysis$n, by=list(data_analysis$econ_participation), FUN=sum)
colnames(econ_participation_count) <- c("Participation", "Frequency")

econ_participation_count$Participation <- factor(econ_participation_count$Participation, c("Never",
                                                                                           "Occasionally",
                                                                                           "Regularly",
                                                                                           "Always")) # Fix the order of rows
econ_participation_count$Frequency <- as.numeric(econ_participation_count$Frequency)

econ_participation_distrib_plot <- ggplot(econ_participation_count, aes(x=Participation, y=Frequency, fill=Frequency)) + geom_bar(stat = "identity",  color = "black", fill = "dodgerblue4",
                                                                                                                                  width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab("Participation in ECON Hearings") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                                    axis.title.x = element_text(margin=margin(10,0,0,0))) +
  scale_y_continuous(limits = c(0,40), expand=c(0,0)) + 
  theme(axis.text.x = element_text(angle = 90, size= 12, hjust = 1, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) 

econ_participation_distrib_plot
#dev.copy2pdf(file="summary statistics/econ_participation_distribution.pdf", width=10, height=6)

# ideological self-placement

ideology_count <- aggregate(data_analysis$n, by=list(data_analysis$q4_1), FUN=sum)
ideology_count[11,] <- c(10, 0)
colnames(ideology_count) <- c("Ideology", "Frequency")

ideology_count$Ideology <- factor(ideology_count$Ideology, c("0",
                                                             "1",
                                                             "2",
                                                             "3",
                                                             "4",
                                                             "5",
                                                             "6",
                                                             "7",
                                                             "8",
                                                             "9",
                                                             "10")) # Fix the order of rows
ideology_count$Frequency <- as.numeric(ideology_count$Frequency)

ideology_distrib_plot <- ggplot(ideology_count, aes(x=Ideology, y=Frequency, fill=Frequency)) + geom_bar(stat = "identity",  color = "black", fill = "dodgerblue4",
                                                                                                         width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab("Left-Right Ideological Self-Placement") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                                           axis.title.x = element_text(margin=margin(10,0,0,0))) +
  scale_y_continuous(limits = c(0,11), expand=c(0,0)) + 
  theme(axis.text.x = element_text(size= 12, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) 

ideology_distrib_plot
#dev.copy2pdf(file="summary statistics/ideology_distribution.pdf", width=10, height=6)

# European integration

eu_integration_count <- aggregate(data_analysis$n, by=list(data_analysis$q4_2), FUN=sum)
colnames(eu_integration_count) <- c("Integration", "Frequency")
eu_integration_count
eu_integration_count$Integration <- factor(eu_integration_count$Integration, c("0",
                                                                               "1",
                                                                               "2",
                                                                               "3",
                                                                               "4",
                                                                               "5",
                                                                               "6",
                                                                               "7",
                                                                               "8",
                                                                               "9",
                                                                               "10")) # Fix the order of rows
eu_integration_count$Frequency <- as.numeric(eu_integration_count$Frequency)

eu_integration_distrib_plot <- ggplot(eu_integration_count, aes(x=Integration, y=Frequency, fill=Frequency)) + geom_bar(stat = "identity",  color = "black", fill = "dodgerblue4",
                                                                                                                        width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab("EU Integration Gone Too Far vs. Should Go Further") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                                                       axis.title.x = element_text(margin=margin(10,0,0,0))) +
  scale_y_continuous(limits = c(0,11), expand=c(0,0)) + 
  theme(axis.text.x = element_text(size= 12, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) 

eu_integration_distrib_plot
#dev.copy2pdf(file="summary statistics/eu_integration_distribution.pdf", width=10, height=6)

# judgment of ECB response to Covid-19

red_white_range <- colorRampPalette(c("firebrick", "white"))
red_white_five <- red_white_range(6)  # to obtain colors used in graph

white_green_range <- colorRampPalette(c("white", "forestgreen"))
white_green_five <- white_green_range(6)   # to obtain colors used in graph

ecb_response_count <- aggregate(data_analysis$n, by=list(data_analysis$q5_1), FUN=sum)
ecb_response_count[11,] <- c(10, 0)
colnames(ecb_response_count) <- c("Response", "Frequency")

ecb_response_count$Response <- factor(ecb_response_count$Response, c("0",
                                                                     "1",
                                                                     "2",
                                                                     "3",
                                                                     "4",
                                                                     "5",
                                                                     "6",
                                                                     "7",
                                                                     "8",
                                                                     "9",
                                                                     "10")) # Fix the order of rows
ecb_response_count$Frequency <- as.numeric(ecb_response_count$Frequency)

ecb_response_distrib_plot <- ggplot(ecb_response_count, aes(x=Response, y=Frequency, fill=Response)) + geom_bar(stat = "identity",  color = "black",
                                                                                                                width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab("Judgement of ECB Policy Response to Covid-19 Crisis") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                                                         axis.title.x = element_text(margin=margin(10,0,0,0))) +
  scale_y_continuous(limits = c(0,13), expand=c(0,0)) + 
  theme(axis.text.x = element_text(size= 12, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) +
  scale_fill_manual(values = c("#B22222", "#C14E4E",
                               "#D07A7A", "#E0A6A6",
                               "#EFD2D2", "#FFFFFF", 
                               "#D2E7D2", "#A6D0A6",
                               "#7AB97A", "#4EA24E", "#228B22"))

ecb_response_distrib_plot
#dev.copy2pdf(file="summary statistics/ecb_response_distribution.pdf", width=10, height=6)

# transparency of ECB decisions

transparency_count <- aggregate(data_analysis$n, by=list(data_analysis$transparency), FUN=sum)
colnames(transparency_count) <- c("Transparency", "Frequency")

transparency_count$Transparency <- factor(transparency_count$Transparency, c("Yes", "No")) # Fix the order of rows
transparency_count$Frequency <- as.numeric(transparency_count$Frequency)

transparency_distrib_plot <- ggplot(transparency_count, aes(x=Transparency, y=Frequency, fill=Transparency)) + geom_bar(stat = "identity",  color = "black", 
                                                                                                                        width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab('Answer to: "Is Transparency of ECB Decisions Adequate?"') + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                                                             axis.title.x = element_text(margin=margin(10,0,0,0))) +
  scale_y_continuous(limits = c(0,30), expand=c(0,0)) + 
  theme(axis.text.x = element_text(size= 12, vjust=0.5), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) +
  scale_fill_manual(values = c("firebrick", "forestgreen"))

transparency_distrib_plot
#dev.copy2pdf(file="summary statistics/transparency_distribution.pdf", width=10, height=6)

# politicization of ECB policymaking

red_white_three <- red_white_range(3)  
white_green_three <- white_green_range(3)  

politicization_count <- aggregate(data_analysis$n, by=list(data_analysis$politicization), FUN=sum)
colnames(politicization_count) <- c("Politicization", "Frequency")

politicization_count$Politicization <- factor(politicization_count$Politicization, c("Strongly disagree",
                                                                                     "Somewhat disagree",
                                                                                     "Neither agree nor disagree",
                                                                                     "Somewhat agree",
                                                                                     "Strongly agree")) # Fix the order of rows
politicization_count$Frequency <- as.numeric(politicization_count$Frequency)

politicization_count_plot <- ggplot(politicization_count, aes(x=Politicization, y=Frequency, fill=Politicization)) + geom_bar(stat = "identity",  color = "black", 
                                                                                                                              width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab('Answer to: "Is the policymaking of the ECB independent from political pressures?"') + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                                                                                       axis.title.x = element_text(margin=margin(15,0,0,0))) +
  scale_y_continuous(limits = c(0,18), expand=c(0,0)) + 
  theme(axis.text.x = element_text(angle = 50, size= 12, hjust=1, vjust=1), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) +
  scale_fill_manual(values = c("#B22222", "#D89090", "#FFFFFF", "#90C490", "#228B22"))


politicization_count_plot
#dev.copy2pdf(file="summary statistics/politicization_distribution.pdf", width=10, height=6)

# Trust in ECB

trust_count <- aggregate(data_analysis$n, by=list(data_analysis$e2_3), FUN=sum)
colnames(trust_count) <- c("Score", "Frequency")

trust_count$Trust <- c("Do not trust at all",
                       "Tend not to trust",
                       "Neither trust nor distrust",
                       "Tend to trust",
                       "Fully trust")

trust_count$Trust <- factor(trust_count$Trust, c("Do not trust at all",
                                                 "Tend not to trust",
                                                 "Neither trust nor distrust",
                                                 "Tend to trust",
                                                 "Fully trust")) # Fix the order of rows

trust_count_plot <- ggplot(trust_count, aes(x=Trust, y=Frequency, fill=Trust)) + geom_bar(stat = "identity",  color = "black", 
                                                                                          width = 0.8, position="dodge") + 
  theme_classic() + ylab("N. of Survey Responses") + xlab('MEPs\' answer to: "How much do you trust the ECB?"') + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                                                                        axis.title.x = element_text(margin=margin(15,0,0,0))) +
  scale_y_continuous(limits = c(0,24), expand=c(0,0)) + 
  theme(axis.text.x = element_text(angle = 50, size= 12, hjust=1, vjust=1), 
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        legend.position = "none",
        axis.title.x = element_text(size= 14),
        axis.title.y = element_text(size= 14)) + geom_text(aes(label=Frequency),
                                                           color = "black", vjust=-1) +
  scale_fill_manual(values = c("#B22222", "#D89090", "#FFFFFF", "#90C490", "#228B22"))


trust_count_plot
#dev.copy2pdf(file="summary statistics/trust_distribution.pdf", width=10, height=6)

# inferential analysis ---------------------------------------------------------

## First experiment

# Summary statistics (first create treatment-specific group, then calculate summary statistics)

data_analysis_e1_control <- data_analysis[data_analysis$treatment_1=="control",]
data_analysis_e1_treatment <- data_analysis[data_analysis$treatment_1=="treatment",]

# E1_2 - Inflation vs. employment
mean(data_analysis_e1_control$e1_2, na.rm=T) #6.103448
sd(data_analysis_e1_control$e1_2, na.rm=T) #2.454512

mean(data_analysis_e1_treatment$e1_2, na.rm=T) #7.347826
sd(data_analysis_e1_treatment$e1_2, na.rm=T) #2.442218

# E2_2 - Importance of secondary objective
mean(data_analysis_e1_control$e1_3, na.rm=T) #3.740741
sd(data_analysis_e1_control$e1_3, na.rm=T) #1.288786

mean(data_analysis_e1_treatment$e1_3, na.rm=T) #4.291667
sd(data_analysis_e1_treatment$e1_3, na.rm=T) #0.8586727

# Econometric analysis (first)

ologit.experiment_1a_1 <- polr(as.ordered(e1_2)~as.factor(treatment_1), data=data_analysis, Hess=TRUE)
ologit.experiment_1b_1 <- polr(as.ordered(e1_3)~as.factor(treatment_1), data=data_analysis, Hess=TRUE)

ologit.coef.experiment_1a <- c(unname(ologit.experiment_1a_1$coefficients[1]),
                               unname(ologit.experiment_1b_1$coefficients[1]))

ologit.lower.experiment_1a <- c(unname(confint(ologit.experiment_1a_1)[1]),
                                unname(confint(ologit.experiment_1b_1)[1]))

ologit.upper.experiment_1a <- c(unname(confint(ologit.experiment_1a_1)[2]),
                                unname(confint(ologit.experiment_1b_1)[2]))

ologit.lower_2.experiment_1a <- c(unname(confint(ologit.experiment_1a_1, level = 0.9)[1]),
                                  unname(confint(ologit.experiment_1b_1, level = 0.9)[1]))

ologit.upper_2.experiment_1a <- c(unname(confint(ologit.experiment_1a_1, level = 0.9)[2]),
                                  unname(confint(ologit.experiment_1b_1, level = 0.9)[2]))

ologit.depvar.experiment_1a <- c("ECB should focus on supporting employment", 
                                 "Secondary mandate importance")

ologit.indepvar.experiment_1a <- c("Unemployment treatment")

ologit.coefficients.experiment_1a <- as.data.frame(cbind(ologit.coef.experiment_1a, 
                                                         ologit.lower.experiment_1a, 
                                                         ologit.upper.experiment_1a, 
                                                         ologit.lower_2.experiment_1a, 
                                                         ologit.upper_2.experiment_1a,
                                                         ologit.depvar.experiment_1a,
                                                         ologit.indepvar.experiment_1a))

ologit.coefficients.experiment_1a$ologit.coef.experiment_1a <- as.numeric(ologit.coefficients.experiment_1a$ologit.coef.experiment_1a)
ologit.coefficients.experiment_1a$ologit.lower.experiment_1a <- as.numeric(ologit.coefficients.experiment_1a$ologit.lower.experiment_1a)
ologit.coefficients.experiment_1a$ologit.upper.experiment_1a <- as.numeric(ologit.coefficients.experiment_1a$ologit.upper.experiment_1a)
ologit.coefficients.experiment_1a$ologit.lower_2.experiment_1a <- as.numeric(ologit.coefficients.experiment_1a$ologit.lower_2.experiment_1a)
ologit.coefficients.experiment_1a$ologit.upper_2.experiment_1a <- as.numeric(ologit.coefficients.experiment_1a$ologit.upper_2.experiment_1a)

ologit.coefficients.experiment_1a$ologit.depvar.experiment_1a <- factor(ologit.coefficients.experiment_1a$ologit.depvar.experiment_1a, levels = c("ECB should focus on supporting employment", 
                                                                                                                                                  "Secondary mandate importance"))
ologit.coefficients.experiment_1a$ologit.indepvar.experiment_1a <- factor(ologit.coefficients.experiment_1a$ologit.indepvar.experiment_1a, levels = c("Unemployment treatment"))

figure_ologit_aggregate_experiment_1a <- ggplot(data = ologit.coefficients.experiment_1a, 
                                                aes (x= ologit.indepvar.experiment_1a, y= ologit.coef.experiment_1a)) +
  geom_errorbar(aes (x = ologit.indepvar.experiment_1a, ymin = ologit.lower_2.experiment_1a, ymax = ologit.upper_2.experiment_1a), width = 0.05, size = 0.5) +
  geom_point(size=6, shape=21, fill="black") + coord_flip() + theme_hc() +
  ylab("Estimated Coefficient") + xlab("Approval Rating") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                  axis.title.x = element_text(margin=margin(20,0,0,0))) + 
  theme(plot.title = element_text(hjust= 0.5, vjust=1, size=18, margin=margin(0,0,20,0))) +
  theme(legend.title=element_blank(),
        legend.text = element_text(size=16),
        legend.key.size = unit(1.5, 'lines')) + 
  geom_hline(yintercept=0, linetype="dashed", color="red") + 
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(vjust=0.5, size=16),
        axis.text.y = element_text(vjust=0.5, size=16),
        legend.position = "none") +
  facet_grid(~ologit.depvar.experiment_1a, scales = "free_x") +
  scale_x_discrete(limits = rev(levels(ologit.coefficients.experiment_1a$ologit.indepvar.experiment_1a)))

figure_ologit_aggregate_experiment_1a
#par(mar=c(5.1, 4.1, 4.1, 3.1)) 
#dev.copy2pdf(file="experiment results/first_experiment_a.pdf", width=14, height=6)

# Econometric analysis (second)

ologit.experiment_1a_2 <- polr(as.ordered(e1_2)~as.numeric(q4_1), data=data_analysis, Hess=TRUE)
ologit.experiment_1a_3 <- polr(as.ordered(e1_2)~as.numeric(q4_2), data=data_analysis, Hess=TRUE)

ologit.experiment_1b_2 <- polr(as.ordered(e1_3)~as.numeric(q4_1), data=data_analysis, Hess=TRUE)
ologit.experiment_1b_3 <- polr(as.ordered(e1_3)~as.numeric(q4_2), data=data_analysis, Hess=TRUE)

ologit.coef.experiment_1b <- c(unname(ologit.experiment_1a_2$coefficients[1]),
                               unname(ologit.experiment_1a_3$coefficients[1]),
                               unname(ologit.experiment_1b_2$coefficients[1]),
                               unname(ologit.experiment_1b_3$coefficients[1]))

ologit.lower.experiment_1b <- c(unname(confint(ologit.experiment_1a_2)[1]),
                                unname(confint(ologit.experiment_1a_3)[1]),
                                unname(confint(ologit.experiment_1b_2)[1]),
                                unname(confint(ologit.experiment_1b_3)[1]))

ologit.upper.experiment_1b <- c(unname(confint(ologit.experiment_1a_2)[2]),
                                unname(confint(ologit.experiment_1a_3)[2]),
                                unname(confint(ologit.experiment_1b_2)[2]),
                                unname(confint(ologit.experiment_1b_3)[2]))

ologit.lower_2.experiment_1b <- c(unname(confint(ologit.experiment_1a_2, level = 0.9)[1]),
                                  unname(confint(ologit.experiment_1a_3, level = 0.9)[1]),
                                  unname(confint(ologit.experiment_1b_2, level = 0.9)[1]),
                                  unname(confint(ologit.experiment_1b_3, level = 0.9)[1]))

ologit.upper_2.experiment_1b <- c(unname(confint(ologit.experiment_1a_2, level = 0.9)[2]),
                                  unname(confint(ologit.experiment_1a_3, level = 0.9)[2]),
                                  unname(confint(ologit.experiment_1b_2, level = 0.9)[2]),
                                  unname(confint(ologit.experiment_1b_3, level = 0.9)[2]))

ologit.depvar.experiment_1b <- c("ECB should focus on supporting employment", 
                                 "ECB should focus on supporting employment", 
                                 "Secondary mandate importance",
                                 "Secondary mandate importance")

ologit.indepvar.experiment_1b <- c("Left-right ideology", 
                                   "Anti- / pro-European ideology")

ologit.coefficients.experiment_1b <- as.data.frame(cbind(ologit.coef.experiment_1b, 
                                                         ologit.lower.experiment_1b, 
                                                         ologit.upper.experiment_1b, 
                                                         ologit.lower_2.experiment_1b, 
                                                         ologit.upper_2.experiment_1b,
                                                         ologit.depvar.experiment_1b,
                                                         ologit.indepvar.experiment_1b))

ologit.coefficients.experiment_1b$ologit.coef.experiment_1b <- as.numeric(ologit.coefficients.experiment_1b$ologit.coef.experiment_1b)
ologit.coefficients.experiment_1b$ologit.lower.experiment_1b <- as.numeric(ologit.coefficients.experiment_1b$ologit.lower.experiment_1b)
ologit.coefficients.experiment_1b$ologit.upper.experiment_1b <- as.numeric(ologit.coefficients.experiment_1b$ologit.upper.experiment_1b)
ologit.coefficients.experiment_1b$ologit.lower_2.experiment_1b <- as.numeric(ologit.coefficients.experiment_1b$ologit.lower_2.experiment_1b)
ologit.coefficients.experiment_1b$ologit.upper_2.experiment_1b <- as.numeric(ologit.coefficients.experiment_1b$ologit.upper_2.experiment_1b)

ologit.coefficients.experiment_1b$ologit.depvar.experiment_1b <- factor(ologit.coefficients.experiment_1b$ologit.depvar.experiment_1b, levels = c("ECB should focus on supporting employment", 
                                                                                                                                                  "Secondary mandate importance"))
ologit.coefficients.experiment_1b$ologit.indepvar.experiment_1b <- factor(ologit.coefficients.experiment_1b$ologit.indepvar.experiment_1b, levels = c("Left-right ideology", 
                                                                                                                                                      "Anti- / pro-European ideology"))

figure_ologit_aggregate_experiment_1b <- ggplot(data = ologit.coefficients.experiment_1b, 
                                                aes (x= ologit.indepvar.experiment_1b, y= ologit.coef.experiment_1b)) +
  geom_errorbar(aes (x = ologit.indepvar.experiment_1b, ymin = ologit.lower_2.experiment_1b, ymax = ologit.upper_2.experiment_1b), width = 0.05, size = 0.5) +
  geom_point(size=6, shape=21, fill="black") + coord_flip() + theme_hc() +
  ylab("Estimated Coefficient") + xlab("Approval Rating") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                  axis.title.x = element_text(margin=margin(20,0,0,0))) + 
  theme(plot.title = element_text(hjust= 0.5, vjust=1, size=18, margin=margin(0,0,20,0))) +
  theme(legend.title=element_blank(),
        legend.text = element_text(size=16),
        legend.key.size = unit(1.5, 'lines')) + 
  geom_hline(yintercept=0, linetype="dashed", color="red") + 
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(vjust=0.5, size=16),
        axis.text.y = element_text(vjust=0.5, size=16),
        legend.position = "none",
        plot.margin = margin(1, 1, 1, 1, "cm")) +
  facet_grid(~ologit.depvar.experiment_1b, scales = "free_x") +
  scale_x_discrete(limits = rev(levels(ologit.coefficients.experiment_1b$ologit.indepvar.experiment_1b)))

figure_ologit_aggregate_experiment_1b
#dev.copy2pdf(file="experiment results/first_experiment_b.pdf", width=14, height=6)

## Second experiment

# Summary statistics (first create treatment-specific group, then calculate summary statistics)

data_analysis_e2_control <- data_analysis[data_analysis$treatment_2=="control",]
data_analysis_e2_hawkish <- data_analysis[data_analysis$treatment_2=="hawkish",]
data_analysis_e2_dovish <- data_analysis[data_analysis$treatment_2=="dovish",]

# E2_2 - Approval of announcemnt
mean(data_analysis_e2_control$e2_2, na.rm=T) #3.055556
sd(data_analysis_e2_control$e2_2, na.rm=T) #1.388896

mean(data_analysis_e2_hawkish$e2_2, na.rm=T) #2.380952
sd(data_analysis_e2_hawkish$e2_2, na.rm=T) #1.657594

mean(data_analysis_e2_dovish$e2_2, na.rm=T) #3.875
sd(data_analysis_e2_dovish$e2_2, na.rm=T) #1.087811

# E2_3 - Trust in the ECB
mean(data_analysis_e2_control$e2_3, na.rm=T) #3.111111
sd(data_analysis_e2_control$e2_3, na.rm=T) #1.182663

mean(data_analysis_e2_hawkish$e2_3, na.rm=T) #2.380952
sd(data_analysis_e2_hawkish$e2_3, na.rm=T) #1.16087

mean(data_analysis_e2_dovish$e2_3, na.rm=T) #3.5
sd(data_analysis_e2_dovish$e2_3, na.rm=T) #0.9660918

# E2_4 - ECB deference
mean(data_analysis_e2_control$e2_4, na.rm=T) #0.375
sd(data_analysis_e2_control$e2_4, na.rm=T) #0.5

mean(data_analysis_e2_hawkish$e2_4, na.rm=T) #0.5
sd(data_analysis_e2_hawkish$e2_4, na.rm=T) #0.5129892

mean(data_analysis_e2_dovish$e2_4, na.rm=T) #0.454545
sd(data_analysis_e2_dovish$e2_4, na.rm=T) #0.522233

# Econometric analysis (first)

ologit.experiment_2a_1 <- polr(as.ordered(e2_2)~as.factor(treatment_2), data=data_analysis, Hess=TRUE)
ologit.experiment_2b_1 <- polr(as.ordered(e2_3)~as.factor(treatment_2), data=data_analysis, Hess=TRUE)
logit.experiment_2c_1 <- glm(e2_4~as.factor(treatment_2), data=data_analysis, family="binomial")

ologit.coef.experiment_2a <- c(unname(ologit.experiment_2a_1$coefficients[1]),
                               unname(ologit.experiment_2a_1$coefficients[2]),
                               unname(ologit.experiment_2b_1$coefficients[1]),
                               unname(ologit.experiment_2b_1$coefficients[2]),
                               unname(logit.experiment_2c_1$coefficients[2]),
                               unname(logit.experiment_2c_1$coefficients[3]))

ologit.lower.experiment_2a <- c(unname(confint(ologit.experiment_2a_1)[1,1]),
                                unname(confint(ologit.experiment_2a_1)[2,1]),
                                unname(confint(ologit.experiment_2b_1)[1,1]),
                                unname(confint(ologit.experiment_2b_1)[2,1]),
                                unname(confint(logit.experiment_2c_1)[2,1]), 
                                unname(confint(logit.experiment_2c_1)[3,1]))

ologit.upper.experiment_2a <- c(unname(confint(ologit.experiment_2a_1)[1,2]),
                                unname(confint(ologit.experiment_2a_1)[2,2]),
                                unname(confint(ologit.experiment_2b_1)[1,2]),
                                unname(confint(ologit.experiment_2b_1)[2,2]),
                                unname(confint(logit.experiment_2c_1)[2,2]),
                                unname(confint(logit.experiment_2c_1)[3,2]))

ologit.lower_2.experiment_2a <- c(unname(confint(ologit.experiment_2a_1, level = 0.9)[1,1]),
                                  unname(confint(ologit.experiment_2a_1, level = 0.9)[2,1]),
                                  unname(confint(ologit.experiment_2b_1, level = 0.9)[1,1]),
                                  unname(confint(ologit.experiment_2b_1, level = 0.9)[2,1]),
                                  unname(confint(logit.experiment_2c_1, level = 0.9)[2,1]),
                                  unname(confint(logit.experiment_2c_1, level = 0.9)[3,1]))

ologit.upper_2.experiment_2a <- c(unname(confint(ologit.experiment_2a_1, level = 0.9)[1,2]),
                                  unname(confint(ologit.experiment_2a_1, level = 0.9)[2,2]),
                                  unname(confint(ologit.experiment_2b_1, level = 0.9)[1,2]),
                                  unname(confint(ologit.experiment_2b_1, level = 0.9)[2,2]),
                                  unname(confint(logit.experiment_2c_1, level = 0.9)[2,2]),
                                  unname(confint(logit.experiment_2c_1, level = 0.9)[3,2]))

ologit.var.experiment_2a <- c("Approval", 
                              "Approval",
                              "Trust",
                              "Trust",
                              "Deference",
                              "Deference")

ologit.est.experiment_2a <- c("Approval 1", 
                              "Approval 2",
                              "Trust 1",
                              "Trust 2",
                              "Deference 1",
                              "Deference 2")

ologit.cat.experiment_2a <- c("Dovish",
                              "Hawkish",
                              "Dovish",
                              "Hawkish",
                              "Dovish",
                              "Hawkish")

ologit.coefficients.experiment_2a <- as.data.frame(cbind(ologit.coef.experiment_2a, 
                                                         ologit.lower.experiment_2a, 
                                                         ologit.upper.experiment_2a, 
                                                         ologit.lower_2.experiment_2a, 
                                                         ologit.upper_2.experiment_2a,
                                                         ologit.var.experiment_2a,
                                                         ologit.est.experiment_2a,
                                                         ologit.cat.experiment_2a))

ologit.coefficients.experiment_2a$ologit.coef.experiment_2a <- as.numeric(ologit.coefficients.experiment_2a$ologit.coef.experiment_2a)
ologit.coefficients.experiment_2a$ologit.lower.experiment_2a <- as.numeric(ologit.coefficients.experiment_2a$ologit.lower.experiment_2a)
ologit.coefficients.experiment_2a$ologit.upper.experiment_2a <- as.numeric(ologit.coefficients.experiment_2a$ologit.upper.experiment_2a)
ologit.coefficients.experiment_2a$ologit.lower_2.experiment_2a <- as.numeric(ologit.coefficients.experiment_2a$ologit.lower_2.experiment_2a)
ologit.coefficients.experiment_2a$ologit.upper_2.experiment_2a <- as.numeric(ologit.coefficients.experiment_2a$ologit.upper_2.experiment_2a)

ologit.coefficients.experiment_2a$ologit.var.experiment_2a <- factor(ologit.coefficients.experiment_2a$ologit.var.experiment_2a, 
                                                                     levels = c("Approval", "Trust", "Deference"))
ologit.coefficients.experiment_2a$ologit.est.experiment_2a <- factor(ologit.coefficients.experiment_2a$ologit.est.experiment_2a, 
                                                                     levels = c("Deference 1", "Deference 2", 
                                                                                "Trust 1", "Trust 2",
                                                                                "Approval 1", "Approval 2"))
ologit.coefficients.experiment_2a$ologit.cat.experiment_2a <- factor(ologit.coefficients.experiment_2a$ologit.cat.experiment_2a, 
                                                                     levels = c("Hawkish", "Dovish"))

figure_ologit_aggregate_experiment_2a <- ggplot(data = ologit.coefficients.experiment_2a, 
                                                aes (x= ologit.cat.experiment_2a, y= ologit.coef.experiment_2a)) +
  geom_errorbar(aes (x = ologit.cat.experiment_2a, ymin = ologit.lower_2.experiment_2a, ymax = ologit.upper_2.experiment_2a), width = 0.05, size = 0.5) +
  geom_point(size=6, shape=21, fill="black") + coord_flip() + theme_hc() +
  ylab("Estimated Coefficient") + xlab("Approval Rating") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                  axis.title.x = element_text(margin=margin(20,0,0,0))) + 
  theme(plot.title = element_text(hjust= 0.5, vjust=1, size=18, margin=margin(0,0,20,0))) +
  theme(legend.title=element_blank(),
        legend.text = element_text(size=16),
        legend.key.size = unit(1.5, 'lines')) + 
  geom_hline(yintercept=0, linetype="dashed", color="red") + 
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(vjust=0.5, size=16),
        axis.text.y = element_text(vjust=0.5, size=16),
        legend.position = "none") +
  facet_grid(~ologit.var.experiment_2a, scales = "free_x") +
  scale_x_discrete(limits = rev(levels(ologit.coefficients.experiment_2a$ologit.cat.experiment_2a)))

figure_ologit_aggregate_experiment_2a
#dev.copy2pdf(file="experiment results/second_experiment_a.pdf", width=14, height=6)

# Econometric analysis (second)

ologit.experiment_2a_2 <- polr(as.ordered(e2_2)~as.numeric(q4_1), data=data_analysis, Hess=TRUE)
ologit.experiment_2a_3 <- polr(as.ordered(e2_2)~as.numeric(q4_2), data=data_analysis, Hess=TRUE)

ologit.experiment_2b_2 <- polr(as.ordered(e2_3)~as.numeric(q4_1), data=data_analysis, Hess=TRUE)
ologit.experiment_2b_3 <- polr(as.ordered(e2_3)~as.numeric(q4_2), data=data_analysis, Hess=TRUE)

logit.experiment_2c_2 <- glm(e2_4~as.numeric(q4_1), data=data_analysis, family="binomial")
logit.experiment_2c_3 <- glm(e2_4~as.numeric(q4_2), data=data_analysis, family="binomial")

ologit.coef.experiment_2b <- c(unname(ologit.experiment_2a_2$coefficients[1]),
                               unname(ologit.experiment_2a_3$coefficients[1]),
                               unname(ologit.experiment_2b_2$coefficients[1]),
                               unname(ologit.experiment_2b_3$coefficients[1]),
                               unname(logit.experiment_2c_2$coefficients[2]),
                               unname(logit.experiment_2c_3$coefficients[2]))

ologit.lower.experiment_2b <- c(unname(confint(ologit.experiment_2a_2)[1]),
                                unname(confint(ologit.experiment_2a_3)[1]),
                                unname(confint(ologit.experiment_2b_2)[1]),
                                unname(confint(ologit.experiment_2b_3)[1]),
                                unname(confint(logit.experiment_2c_2)[2,1]), 
                                unname(confint.default(logit.experiment_2c_3)[2,1]))

ologit.upper.experiment_2b <- c(unname(confint(ologit.experiment_2a_2)[2]),
                                -unname(confint(ologit.experiment_2a_3)[2]),
                                unname(confint(ologit.experiment_2b_2)[2]),
                                -unname(confint(ologit.experiment_2b_3)[2]),
                                unname(confint(logit.experiment_2c_2)[2,2]), 
                                -unname(confint.default(logit.experiment_2c_3)[2,2]))

ologit.lower_2.experiment_2b <- c(unname(confint(ologit.experiment_2a_2, level = 0.9)[1]),
                                  unname(confint(ologit.experiment_2a_3, level = 0.9)[1]),
                                  unname(confint(ologit.experiment_2b_2, level = 0.9)[1]),
                                  unname(confint(ologit.experiment_2b_3, level = 0.9)[1]),
                                  unname(confint(logit.experiment_2c_2, level = 0.9)[2,1]), 
                                  unname(confint.default(logit.experiment_2c_3, level = 0.9)[2,1]))

ologit.upper_2.experiment_2b <- c(unname(confint(ologit.experiment_2a_2, level = 0.9)[2]),
                                  unname(confint(ologit.experiment_2a_3, level = 0.9)[2]),
                                  unname(confint(ologit.experiment_2b_2, level = 0.9)[2]),
                                  unname(confint(ologit.experiment_2b_3, level = 0.9)[2]),
                                  unname(confint(logit.experiment_2c_2, level = 0.9)[2,2]), 
                                  unname(confint.default(logit.experiment_2c_3, level = 0.9)[2,2]))

ologit.var.experiment_2b <- c("Approval", 
                              "Approval",
                              "Trust",
                              "Trust",
                              "Deference",
                              "Deference")

ologit.est.experiment_2b <- c("Approval 3", 
                              "Approval 4",
                              "Trust 3",
                              "Trust 4",
                              "Deference 3",
                              "Deference 4")

ologit.cat.experiment_2b <- c("Left-right ideology",
                              "Anti- / pro-European ideology",
                              "Left-right ideology",
                              "Anti- / pro-European ideology",
                              "Left-right ideology",
                              "Anti- / pro-European ideology")

ologit.coefficients.experiment_2b <- as.data.frame(cbind(ologit.coef.experiment_2b, 
                                                         ologit.lower.experiment_2b, 
                                                         ologit.upper.experiment_2b, 
                                                         ologit.lower_2.experiment_2b, 
                                                         ologit.upper_2.experiment_2b,
                                                         ologit.var.experiment_2b,
                                                         ologit.est.experiment_2b,
                                                         ologit.cat.experiment_2b))

ologit.coefficients.experiment_2b$ologit.coef.experiment_2b <- as.numeric(ologit.coefficients.experiment_2b$ologit.coef.experiment_2b)
ologit.coefficients.experiment_2b$ologit.lower.experiment_2b <- as.numeric(ologit.coefficients.experiment_2b$ologit.lower.experiment_2b)
ologit.coefficients.experiment_2b$ologit.upper.experiment_2b <- as.numeric(ologit.coefficients.experiment_2b$ologit.upper.experiment_2b)
ologit.coefficients.experiment_2b$ologit.lower_2.experiment_2b <- as.numeric(ologit.coefficients.experiment_2b$ologit.lower_2.experiment_2b)
ologit.coefficients.experiment_2b$ologit.upper_2.experiment_2b <- as.numeric(ologit.coefficients.experiment_2b$ologit.upper_2.experiment_2b)

ologit.coefficients.experiment_2b$ologit.var.experiment_2b <- factor(ologit.coefficients.experiment_2b$ologit.var.experiment_2b, 
                                                                     levels = c("Approval", "Trust", "Deference"))
ologit.coefficients.experiment_2b$ologit.est.experiment_2b <- factor(ologit.coefficients.experiment_2b$ologit.est.experiment_2b, 
                                                                     levels = c("Deference 3", "Deference 4",
                                                                                "Trust 3", "Trust 4",
                                                                                "Approval 3", "Approval 4"))
ologit.coefficients.experiment_2b$ologit.cat.experiment_2b <- factor(ologit.coefficients.experiment_2b$ologit.cat.experiment_2b, 
                                                                     levels = c("Left-right ideology", "Anti- / pro-European ideology"))

figure_ologit_aggregate_experiment_2b <- ggplot(data = ologit.coefficients.experiment_2b, 
                                                aes (x= ologit.cat.experiment_2b, y= ologit.coef.experiment_2b)) +
  geom_errorbar(aes (x = ologit.cat.experiment_2b, ymin = ologit.lower_2.experiment_2b, ymax = ologit.upper_2.experiment_2b), width = 0.05, size = 0.5) +
  geom_point(size=6, shape=21, fill="black") + coord_flip() + theme_hc() +
  ylab("Estimated Coefficient") + xlab("Approval Rating") + theme(axis.title.y = element_text(margin=margin(0,20,0,0)),
                                                                  axis.title.x = element_text(margin=margin(20,0,0,0))) + 
  theme(plot.title = element_text(hjust= 0.5, vjust=1, size=18, margin=margin(0,0,20,0))) +
  theme(legend.title=element_blank(),
        legend.text = element_text(size=16),
        legend.key.size = unit(1.5, 'lines')) + 
  geom_hline(yintercept=0, linetype="dashed", color="red") + 
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_text(vjust=0.5, size=16),
        axis.text.y = element_text(vjust=0.5, size=16),
        legend.position = "none",
        plot.margin = margin(1, 1, 1, 1, "cm")) +
  facet_grid(~ologit.var.experiment_2b, scales = "free_x") +
  scale_x_discrete(limits = rev(levels(ologit.coefficients.experiment_2b$ologit.cat.experiment_2b))) +
  theme(panel.spacing.x = unit(10, "mm"))

figure_ologit_aggregate_experiment_2b
#dev.copy2pdf(file="experiment results/second_experiment_b.pdf", width=16, height=6)